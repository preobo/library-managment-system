package banking;
import java.util.ArrayList;

public class BankAccount implements TransactionLogger {
	private int accountNumber;
	private String holderName;
	private double balance;
	private String accountType;
	private ArrayList<String> logHistory = new ArrayList<String>();
	
	BankAccount(){
		accountNumber = 0000;
		holderName = "";
		balance = 0000;
		accountType = "";
	}
	
	public BankAccount(int accountNumber, String holderName, double balance, String accountType) {
		this.accountNumber = accountNumber;
		this.holderName = holderName;
		this.balance = balance;
		this.accountType = accountType;
		
	}
	public void deposit(double amount) {
		balance += amount;
		logTransaction("Deposited: " + amount);
	}
	public void withdraw(double amount) {
		if(balance >= amount) {
			balance -= amount;
			logTransaction("Withdrew: " + amount);
		}else {
			System.out.println("Insufficant funds");
		}
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	public ArrayList<String> getLogHistory() {
		return logHistory;
	}

	public void setLogHistory(ArrayList<String> logHistory) {
		this.logHistory = logHistory;
	}
	public void displayAccountInfo() {
		System.out.println("Displaying account information...");
		System.out.println("Hello " + holderName);
		System.out.println("Account number: " + accountNumber);
		System.out.println("Account type: " + accountType);
		System.out.println("Balance: " + balance);
	}

	@Override
	public void logTransaction(String message) {
		//viewTransactionHistory.add(message);
		logHistory.add(message);
		
	}

	public int getAccountNumber() {
		// TODO Auto-generated method stub
		return accountNumber;
	}

		
}

	


