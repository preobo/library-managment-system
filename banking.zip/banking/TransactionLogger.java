package banking;

public interface TransactionLogger {

	void logTransaction(String message);
	
}
