package banking;
import java.util.ArrayList;
public class Bank {
	ArrayList<BankAccount> accounts;
	
	Bank(){
		accounts = new ArrayList<BankAccount>();
	}
	
	public void createAccount(BankAccount account) {
		accounts.add(account);
		System.out.println("Accept created successfully for " + account.getHolderName());
	}
	public void deposit(int accountNumber, double amount) {
		if(amount <=0) {
			System.out.println("Deposit amount must be positive");
			return;
	}
		
		for(BankAccount account: accounts) {
			if(account.getAccountNumber() == accountNumber) {
				account.deposit(amount);
				System.out.println("Deposit successful. New balance: " + account.getBalance());
				return;
			}
		}
	
		System.out.println("Account not found");
	
	}
	public void withdraw(int accountNumber, double amount) {
		if(amount <=0) {
			System.out.println("Withdraw amount must be positive");
			return;
		}
		for(BankAccount account: accounts) {
			if(account.getAccountNumber() == accountNumber) {
				account.withdraw(amount);
				System.out.println("Withdraw successful. New balance: " + account.getBalance());
				
			}
		}
	
		System.out.println("Account not found");
	}
	public void transferFunds(int checkingAccountNumber, int savingsAccountNumber, double amount) {
	    if(amount <= 0) {
	        System.out.println("Transfer amount must be positive");
	        return;
	    }
	    
	    BankAccount checkingAccount = null;
	    BankAccount savingsAccount = null;

	    
	    for(BankAccount account : accounts) {
	        if(account.getAccountNumber() == checkingAccountNumber) {
	            checkingAccount = account;
	        }
	        if(account.getAccountNumber() == savingsAccountNumber) {
	            savingsAccount = account;
	        }
	    }
	    
	    if(checkingAccount == null) {
	        System.out.println("Checking account not found");
	        return;
	    }
	    
	    if(savingsAccount == null) {
	        System.out.println("Savings account not found");
	        return;
	    }

	    
	    if(checkingAccount.getBalance() < amount) {
	        System.out.println("Insufficient balance in the Checking account");
	        return;
	    }

	    
	    checkingAccount.setBalance(checkingAccount.getBalance() - amount);
	    savingsAccount.setBalance(savingsAccount.getBalance() + amount);

	    System.out.println("Transfer successful! New balance of Checking Account: " + checkingAccount.getBalance());
	    System.out.println("New balance of Savings Account: " + savingsAccount.getBalance());
	    
	    checkingAccount.logTransaction("Transferred $" + amount + " to Savings account #" + savingsAccountNumber);
	    savingsAccount.logTransaction("Received $" + amount + " from Checking account #" + checkingAccountNumber);
	}

}