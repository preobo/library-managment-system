package banking;

public class CheckingaAccount extends BankAccount {
	double overdraftFee;

	public CheckingaAccount(int accountNumber, String holderName, double balance, double overdraftFee) {
		// Call the constructor of the superclass BankAccount 
		super(accountNumber, holderName, balance, "Checking"); 
		
		//Assigning the parameter to the instance variable
		this.overdraftFee = overdraftFee;
	}
	@Override 
	public void withdraw(double amount) { 
		if(amount <= getBalance()) {
			super.withdraw(amount);
			logTransaction("Withdrew: $" + amount);
		} else{
			double totalAmount = amount + overdraftFee;
			if(getBalance() - totalAmount < 0) {
			  System.out.println("Overdraft applied. Your balance is negative");
			}
			logTransaction("Withdrew: $" + amount + " with an overdraft fee of: $" + overdraftFee);
			setBalance(getBalance() - totalAmount);
	}
		
	}
}

