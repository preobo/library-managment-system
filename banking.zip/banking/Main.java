package banking;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Main {
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Bank bank = new Bank();
    
    while(true) {
    	System.out.println("Bank Management System: ");
    	System.out.println("1. Create Account");
    	System.out.println("2. Deposit");
    	System.out.println("3. Withdraw");
        System.out.println("4. Transfer Funds");
        System.out.println("5. View Transaction History");
        System.out.println("6. Display All Accounts");
        System.out.println("7. Exit");
        System.out.print("Enter your choice: ");
        
        int choice = scanner.nextInt();
        
        switch(choice) {
        case 1:
        	scanner.nextLine();
        	System.out.println("Enter the account holder's name: ");
        	String holderName = scanner.nextLine();
        	
        	int accountNumber = ThreadLocalRandom.current().nextInt(10000000, 100000000);
        	
        	System.out.println("New account number created: " + accountNumber);
        	
        	System.out.println("Enter your starting balance: ");
        	double balance = scanner.nextDouble();
        	
        	System.out.println("Enter the type of account you want to create - 1 for Checking, 2 for Savings: ");
        	int accountType = scanner.nextInt();
        	
        	if (accountType == 1) {
        		System.out.println("Enter overdraft fee for Checkings Account: ");
        		double overdraftFee = scanner.nextDouble();
        		CheckingAccount newCheckingAccount = new CheckingAccount(accountNumber, holderName, balance, overdraftFee);
        		bank.createAccount(newCheckingAccount);
        	} else if (accountType == 2) {
        		System.out.println("Enter starting balance for Savings account: ");
        		double minimumBalance = scanner.nextDouble();
        		System.out.println("Enter the interest rate for Savings account: ");
        		double interestRate = scanner.nextDouble();
        		SavingsAccount newSavingsAccount = new SavingsAccount(accountNumber, holderName, balance, minimumBalance, interestRate);
        		bank.createAccount(newSavingsAccount);
        	} else {
        		System.out.println("You enter an invalid account type. Try again.");
        		
        	}
        	System.out.println("Your Account was created successfully, your account number is: " + accountNumber);
        	break;
        	
        case 2:
        	System.out.println("Enter the number of the account you would like to deposit money into: ");
        	accountNumber = scanner.nextInt();
        	System.out.println("Enter the amount you would like to deposit: ");
        	double depositAmount = scanner.nextDouble();
        	bank.deposit(accountNumber, depositAmount);
        	break;
        	
        case 3:
        	System.out.println("Enter the number of the account you would like to withdraw money from: ");
            accountNumber = scanner.nextInt();
            System.out.println("Enter the amount you would like to withdraw: ");
            double withdrawalAmount = scanner.nextDouble();
            bank.withdraw(accountNumber, withdrawalAmount);
            break;
            
        case 4:
            System.out.println("Enter the account number you would like to transfer money from: ");
            int fromAccount = scanner.nextInt();
            System.out.println("Enter the account number you would like to transfer money into: ");
            int toAccount = scanner.nextInt();
            System.out.println("Enter the amount you want to transfer: ");
            double transferAmount = scanner.nextDouble();
            bank.transferFunds(fromAccount, toAccount, transferAmount);  
            break;
            
        case 5:
            System.out.println("Enter the number of the account's history you want to view: ");
            accountNumber = scanner.nextInt();
            bank.viewTransactionHistory(accountNumber);
            break;
            
        case 6: 
            bank.displayAllAccounts();
            break;
            
        case 7:  
        	System.out.println("Exiting the banking system.");
            scanner.close();
            return;
            
        default:
            System.out.println("Invalid choice. Please try again.");    
        
        
        }
    }
    	
    }
}


