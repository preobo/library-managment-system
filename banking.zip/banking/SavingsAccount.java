package banking;

public class SavingsAccount extends BankAccount {
	double minimumBalance;
	double monthlyInterest;
	
	public SavingsAccount(int accountNumber, String holderName, double balance, double minimumBalance, double monthlyInterest) {
		super(accountNumber, holderName, balance, "Savings");
		this.minimumBalance = minimumBalance;
		this.monthlyInterest = monthlyInterest;
	}
	public void applyInterest(double balance) {
		double interest = getBalance() * interestRate;
        setBalance(getBalance() + interest);
        logTransaction("Applied one-time interest of " + (interestRate * 100) + "% to balance.");
	}
	@Override 
	public void withdraw(double amount) {
		if(getBalance() - amount >= minimumBalance) {
			super.withdraw(amount);
			logTransaction("Withdrew: " + amount);
			System.out.println("New balance after withdraw is: " + getBalance());
		}else {
			System.out.println("Cannot withdraw, minimum balance is not met");
		}
	}

}

